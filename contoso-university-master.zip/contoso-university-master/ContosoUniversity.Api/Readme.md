## ContosoUniversity.Api

### Run Api with Swagger UI
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniversity.Api
dotnet run
```