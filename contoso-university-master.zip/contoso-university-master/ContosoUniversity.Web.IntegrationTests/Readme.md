## ContosoUniversity.Web.IntegrationTests

### Run Integration Tests from command line
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniverity.Web.IntegrationTests
dotnet test
```

### References
[Integration Test in Asp.Net Core](https://docs.microsoft.com/en-us/aspnet/core/test/integration-tests?view=aspnetcore-2.1)