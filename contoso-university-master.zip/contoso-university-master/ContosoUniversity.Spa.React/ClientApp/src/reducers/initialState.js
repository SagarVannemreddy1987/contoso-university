export default {
    departments: [],
    courses: [],
    ajaxCallsInProgress: 0
};