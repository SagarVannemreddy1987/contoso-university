import React from 'react';
import RegisterForm from '../forms/Register';

export default function () {
    return (
        <div className="body-content">
            <h2>Register</h2>
            <RegisterForm />
        </div>
    );
}