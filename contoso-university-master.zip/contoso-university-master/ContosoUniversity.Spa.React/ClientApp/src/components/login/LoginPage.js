import React from 'react';

export default function(){
    return(
        <div>
            <h1>Login Page</h1>
        </div>
    );
}