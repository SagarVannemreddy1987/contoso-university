import React from 'react';

export default function () {
    return (
        <footer className="container">
            <p>&copy; 2018 - Contoso University</p>
        </footer>
    );
}