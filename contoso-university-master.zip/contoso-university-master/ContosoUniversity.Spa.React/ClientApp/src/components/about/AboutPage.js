import React from 'react';

export default function() {
    return(
        <div>
            <h1>About Page</h1>
        </div>
    );
}