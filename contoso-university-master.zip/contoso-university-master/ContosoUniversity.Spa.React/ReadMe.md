## ContosoUniversity.Spa.React
Single Page Application (SPA) using React front-end framework and WebApi backend

### Prerequisites
- .NET Core SDK v2.1.0 or later
- Node.js v6.0 or later

### Run App
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniversity.Spa.React
dotnet run
```