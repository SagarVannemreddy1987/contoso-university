## ContosoUniversity.Data.Tests
Test project for ContosoUniversity.Data.

### Run tests
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniversity.Data.Tests
dotnet test
```