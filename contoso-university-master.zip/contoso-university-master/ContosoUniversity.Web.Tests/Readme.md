## ContosoUniversity.Web.Test
Unit test project for [ContosoUniversity.Web](https://github.com/alimon808/contoso-university/tree/master/ContosoUniversity.Web)

### Run tests
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniversity.Web.Test
dotnet test
```