﻿namespace ContosoUniversity.Web.ViewModels
{
    public class ManageIndexViewModel
    {
        public bool HasPassword { get; set; }
        public string PhoneNumber { get; set; }
        public bool TwoFactor { get; set; }
    }
}