## ContosoUniversity.Web

### Run Mvc App
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUnversity.Web
dotnet run
```