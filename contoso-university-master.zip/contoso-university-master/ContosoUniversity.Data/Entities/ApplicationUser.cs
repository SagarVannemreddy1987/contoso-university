using Microsoft.AspNetCore.Identity;

namespace ContosoUniversity.Data.Entities
{
    public class ApplicationUser : IdentityUser
    {
    }
}