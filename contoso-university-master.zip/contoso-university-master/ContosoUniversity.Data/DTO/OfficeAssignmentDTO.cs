﻿namespace ContosoUniversity.Data.DTO
{
    public class OfficeAssignmentDTO
    {
        public int ID { get; set; }
        public int InstructorID { get; set; }
        public string Location { get; set; }
    }
}
