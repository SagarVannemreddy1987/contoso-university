﻿namespace ContosoUniversity.Data.DTO
{
    public class CourseAssignmentsDTO
    {
        public int InstructorID { get; set; }
        public int CourseID { get; set; }
    }
}
