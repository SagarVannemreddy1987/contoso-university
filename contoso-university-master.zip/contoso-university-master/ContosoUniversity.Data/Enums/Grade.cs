﻿namespace ContosoUniversity.Data.Enums
{
    public enum Grade
    {
        A,B,C,D,F
    }
}
