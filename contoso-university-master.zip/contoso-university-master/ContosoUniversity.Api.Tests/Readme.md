## ContosoUniversity.Api.Tests

### Run tests
```
git clone https://github.com/alimon808/contoso-university.git
cd ContosoUniversity.Api.Tests
dotnet test
```