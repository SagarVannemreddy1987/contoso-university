### ContosoUniversity.Common

Shared library between Api and Web projects