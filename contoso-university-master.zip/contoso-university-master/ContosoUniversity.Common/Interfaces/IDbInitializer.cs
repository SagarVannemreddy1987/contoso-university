﻿namespace ContosoUniversity.Common.Interfaces
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
