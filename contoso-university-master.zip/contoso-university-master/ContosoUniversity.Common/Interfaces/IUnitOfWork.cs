﻿namespace ContosoUniversity.Common.Interfaces
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}